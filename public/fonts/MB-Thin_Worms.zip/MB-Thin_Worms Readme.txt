MB Thin Worms - Spiked, Horror Black Metal Font by ModBlackmoon. [Hand-drawing + Photoshop]

INFO: 
Incl. English letters and Numbers, some most common signs, some letters from nordic languages. May be scaled to extra large size without quality loss.

LICENSE: 
Free for personal use. For commercial use credits are required. No modify.

Designed: Summer 2012 (sketched) / May 2013 (released).
Author: ModBlackmoon
WEB: modblackmoon.com  |  facebook.com/ModBlackmoon.Art